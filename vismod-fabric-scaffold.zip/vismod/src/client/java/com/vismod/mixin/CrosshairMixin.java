package com.vismod.mixin;

import com.vismod.module.ModuleManager;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NOTE on method names: Yarn mapping method names occasionally shift
 * between snapshots. If this fails to compile against your exact
 * 1.21.11 mappings, open InGameHud in your IDE, find the crosshair
 * render method (search "renderCrosshair"), and update the @Inject
 * method= value to match.
 */
@Mixin(InGameHud.class)
public abstract class CrosshairMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void vismod$maybeCancelVanillaCrosshair(net.minecraft.client.gui.DrawContext context,
                                                      net.minecraft.client.render.RenderTickCounter tickCounter,
                                                      CallbackInfo ci) {
        if (ModuleManager.isEnabled("custom_crosshair")) {
            ci.cancel();
        }
    }
}
