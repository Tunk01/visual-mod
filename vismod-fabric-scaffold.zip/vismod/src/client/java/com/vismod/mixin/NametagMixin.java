package com.vismod.mixin;

import com.vismod.module.ModuleManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Unlike the other toggles, "Nametags" defaults to ON in the config UI
 * (matches the screenshot), so here we cancel-to-false only when the
 * module has explicitly been turned OFF.
 */
@Mixin(EntityRenderer.class)
public abstract class NametagMixin<T extends Entity> {

    @Inject(method = "hasLabel", at = @At("HEAD"), cancellable = true)
    private void vismod$hideLabelsWhenDisabled(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (!ModuleManager.isEnabled("nametags")) {
            cir.setReturnValue(false);
        }
    }
}
