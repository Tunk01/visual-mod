package com.vismod.mixin;

import com.vismod.module.ModuleManager;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * As with the crosshair mixin: if "renderWeather" doesn't match your exact
 * 1.21.11 mappings, search WorldRenderer for the rain/snow render method
 * and point @Inject(method=...) at it.
 */
@Mixin(WorldRenderer.class)
public abstract class WeatherMixin {

    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true)
    private void vismod$maybeCancelWeather(CallbackInfo ci) {
        if (!ModuleManager.isEnabled("weather")) {
            ci.cancel();
        }
    }
}
