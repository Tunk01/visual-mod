package com.vismod.gui;

import com.vismod.gui.widget.GlassButton;
import com.vismod.gui.widget.ModuleRow;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.module.ModuleManager;
import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The "Visuals" tab from the reference screenshots: search box, All /
 * Entities / Motion / Starred filter chips, two columns of ModuleRows,
 * and simple pagination (10 rows per column = 20 per page). Presets /
 * World / HUD / Style / Configs / Setup are stubbed as placeholder tabs
 * you can flesh out the same way.
 */
public class VisualsConfigScreen extends Screen {

    private enum Filter { ALL, ENTITIES, MOTION, STARRED }

    private static final int ROWS_PER_COLUMN = 10;
    private static final int ROW_HEIGHT = 20;

    private final Screen parent;
    private TextFieldWidget searchBox;
    private Filter filter = Filter.ALL;
    private int page = 0;
    private List<Module> filtered = new ArrayList<>();

    public VisualsConfigScreen(Screen parent) {
        super(Text.literal("VisMod Config"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int panelX = width / 2 - 220;
        int panelY = height / 2 - 150;

        // top nav chips (Visuals / Presets / World / HUD / Style / Configs / Setup) - only Visuals is wired up
        String[] tabs = {"Visuals", "Presets", "World", "HUD", "Style", "Configs", "Setup"};
        int tabX = panelX;
        for (String tab : tabs) {
            int tabWidth = textRenderer.getWidth(tab) + 16;
            boolean active = tab.equals("Visuals");
            addDrawableChild(GlassButton.of(tabX, panelY, tabWidth, 18, Text.literal(tab), btn -> {
                if (!active) {
                    // TODO: swap to the matching sub-screen once you build Presets/World/etc.
                }
            }));
            tabX += tabWidth + 4;
        }

        // search box
        searchBox = new TextFieldWidget(textRenderer, panelX, panelY + 26, 300, 18, Text.literal("Search modules"));
        searchBox.setPlaceholder(Text.literal("Search modules"));
        searchBox.setChangedListener(text -> { page = 0; refreshFiltered(); });
        addDrawableChild(searchBox);

        // filter chips
        int chipX = panelX;
        int chipY = panelY + 50;
        for (Filter f : Filter.values()) {
            String label = f.name().charAt(0) + f.name().substring(1).toLowerCase(Locale.ROOT);
            int chipWidth = textRenderer.getWidth(label) + 14;
            addDrawableChild(GlassButton.of(chipX, chipY, chipWidth, 16, Text.literal(label), btn -> {
                filter = f;
                page = 0;
                refreshFiltered();
            }));
            chipX += chipWidth + 4;
        }

        // pagination controls, bottom-right of the panel
        int footerY = panelY + 300;
        addDrawableChild(GlassButton.of(panelX + 380, footerY, 18, 16, Text.literal("<"), btn -> {
            if (page > 0) { page--; rebuildRows(); }
        }));
        addDrawableChild(GlassButton.of(panelX + 402, footerY, 18, 16, Text.literal(">"), btn -> {
            int maxPage = Math.max(0, (filtered.size() - 1) / (ROWS_PER_COLUMN * 2));
            if (page < maxPage) { page++; rebuildRows(); }
        }));

        // close
        addDrawableChild(GlassButton.of(panelX + 420, panelY, 18, 18, Text.literal("x"),
                btn -> close()));

        refreshFiltered();
    }

    private void refreshFiltered() {
        String query = searchBox == null ? "" : searchBox.getText().toLowerCase(Locale.ROOT);
        filtered = ModuleManager.all().stream()
                .filter(m -> matchesFilter(m))
                .filter(m -> query.isEmpty() || m.displayName().toLowerCase(Locale.ROOT).contains(query))
                .toList();
        rebuildRows();
    }

    private boolean matchesFilter(Module m) {
        return switch (filter) {
            case ALL -> true;
            case ENTITIES -> m.category() == ModuleCategory.ENTITIES;
            case MOTION -> m.category() == ModuleCategory.MOTION;
            case STARRED -> m.isStarred();
        };
    }

    private void rebuildRows() {
        // remove previously-added rows (anything after the fixed chrome) - simplest way is to
        // track them separately; for brevity we just re-init() in this scaffold.
        clearAndReaddRows();
    }

    private final List<ModuleRow> activeRows = new ArrayList<>();

    private void clearAndReaddRows() {
        for (ModuleRow row : activeRows) {
            remove(row);
        }
        activeRows.clear();

        int panelX = width / 2 - 220;
        int panelY = height / 2 - 150;
        int listTop = panelY + 74;
        int colWidth = 210;

        int startIndex = page * ROWS_PER_COLUMN * 2;
        for (int i = 0; i < ROWS_PER_COLUMN * 2; i++) {
            int index = startIndex + i;
            if (index >= filtered.size()) break;

            int col = i / ROWS_PER_COLUMN;
            int row = i % ROWS_PER_COLUMN;
            int x = panelX + col * (colWidth + 10);
            int y = listTop + row * ROW_HEIGHT;

            ModuleRow widget = new ModuleRow(filtered.get(index), x, y, colWidth, ROW_HEIGHT - 2);
            activeRows.add(widget);
            addDrawableChild(widget);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        GlassRenderer.blurBackdrop(delta);
        renderBackground(context, mouseX, mouseY, delta);

        int panelX = width / 2 - 220;
        int panelY = height / 2 - 150;
        GlassRenderer.panel(context, panelX - 10, panelY - 6, 450, 320, 0x33101014, 0x30FFFFFF);

        super.render(context, mouseX, mouseY, delta);

        // footer: "N modules  M enabled   page/pages"
        int maxPage = Math.max(0, (filtered.size() - 1) / (ROWS_PER_COLUMN * 2)) + 1;
        String footer = ModuleManager.totalCount() + " modules   " + ModuleManager.enabledCount() + " enabled   "
                + (page + 1) + "/" + maxPage;
        context.drawTextWithShadow(textRenderer, footer, panelX, panelY + 302, 0x90FFFFFF);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
