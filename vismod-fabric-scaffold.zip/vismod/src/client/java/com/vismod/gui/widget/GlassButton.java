package com.vismod.gui.widget;

import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** A ButtonWidget that paints itself as a frosted-glass pill instead of the vanilla stone texture. */
public class GlassButton extends ButtonWidget {

    protected GlassButton(int x, int y, int width, int height, Text message, PressAction onPress) {
        super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    public static GlassButton of(int x, int y, int width, int height, Text message, PressAction onPress) {
        return new GlassButton(x, y, width, height, message, onPress);
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        boolean hovered = isHovered();
        GlassRenderer.panel(context, getX(), getY(), getWidth(), getHeight(),
                hovered ? 0x4D000000 : 0x33000000,
                hovered ? 0x60FFFFFF : 0x30FFFFFF);

        int textColor = active ? 0xFFFFFFFF : 0xFF909090;
        context.drawCenteredTextWithShadow(
                net.minecraft.client.MinecraftClient.getInstance().textRenderer,
                getMessage(),
                getX() + getWidth() / 2,
                getY() + (getHeight() - 8) / 2,
                textColor);
    }
}
