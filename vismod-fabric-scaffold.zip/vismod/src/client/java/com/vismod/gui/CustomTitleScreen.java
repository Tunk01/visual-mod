package com.vismod.gui;

import com.vismod.config.BackgroundImageManager;
import com.vismod.gui.widget.GlassButton;
import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Replaces vanilla's TitleScreen (swapped in from VisModClient via
 * ScreenEvents.BEFORE_INIT - see that class for why no mixin is needed).
 * Layout matches the reference screenshot: big clock + date + greeting up
 * top, Singleplayer/Multiplayer as the primary glass buttons, a row of
 * secondary glass buttons (Theme/Studio/Mods/Realms/Options/Quit) along
 * the bottom.
 */
public class CustomTitleScreen extends Screen {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public CustomTitleScreen() {
        super(Text.literal("VisMod Title Screen"));
    }

    @Override
    protected void init() {
        int centerX = width / 2;

        // primary buttons
        int primaryWidth = 200;
        int primaryY = height / 2 + 10;
        addDrawableChild(GlassButton.of(centerX - primaryWidth - 5, primaryY, primaryWidth, 26,
                Text.literal("Singleplayer"),
                btn -> client.setScreen(new SelectWorldScreen(this))));
        addDrawableChild(GlassButton.of(centerX + 5, primaryY, primaryWidth, 26,
                Text.literal("Multiplayer"),
                btn -> client.setScreen(new MultiplayerScreen(this))));

        // secondary row along the bottom, matches "Theme Studio Mods Realms Options Quit"
        String[] labels = {"Theme", "Studio", "Mods", "Realms", "Options", "Quit"};
        int secondaryWidth = 72;
        int gap = 6;
        int totalWidth = labels.length * secondaryWidth + (labels.length - 1) * gap;
        int startX = centerX - totalWidth / 2;
        int secondaryY = height - 34;

        for (int i = 0; i < labels.length; i++) {
            String label = labels[i];
            int x = startX + i * (secondaryWidth + gap);
            addDrawableChild(GlassButton.of(x, secondaryY, secondaryWidth, 20, Text.literal(label), btn -> onSecondary(label)));
        }
    }

    private void onSecondary(String label) {
        switch (label) {
            case "Theme" -> BackgroundImageManager.promptAndLoad(null);
            case "Options" -> client.setScreen(new OptionsScreen(this, client.options));
            case "Quit" -> client.scheduleStop();
            // "Studio", "Mods", "Realms" - wire these to your own screens as you build them out
            default -> {}
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackgroundLayer(context, delta);
        super.render(context, mouseX, mouseY, delta);
        renderClockAndGreeting(context);
    }

    private void renderBackgroundLayer(DrawContext context, float delta) {
        if (BackgroundImageManager.hasCustomBackground()) {
            // NOTE: DrawContext#drawTexture's exact overload (whether it wants a RenderLayer
            // function reference like this, or just an Identifier) depends on your exact 1.21.11
            // mappings - check DrawContext in your IDE if this line doesn't compile.
            context.drawTexture(
                    net.minecraft.client.render.RenderLayer::getGuiTextured,
                    BackgroundImageManager.textureId(),
                    0, 0, 0, 0, width, height, width, height);
            // darken slightly so white text/buttons stay legible over any photo
            context.fill(0, 0, width, height, 0x60000000);
        } else {
            // fallback: vanilla panorama look-alike - simple vertical gradient
            context.fillGradient(0, 0, width, height, 0xFF1A1A22, 0xFF05050A);
        }
    }

    private void renderClockAndGreeting(DrawContext context) {
        LocalDateTime now = LocalDateTime.now();
        String time = now.format(TIME_FORMAT);
        String date = now.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault())
                + ", " + now.getDayOfMonth() + " "
                + now.getMonth().getDisplayName(TextStyle.FULL, Locale.getDefault());

        int centerX = width / 2;
        int y = 40;

        context.drawCenteredTextWithShadow(textRenderer, date, centerX, y, 0xFFE4E4E8);
        // big clock - drawn 2x scale by hand since DrawContext has no native font-scale draw helper.
        // NOTE: exact MatrixStack method names (push/pop/translate/scale) shifted slightly around
        // the 1.21.2 rendering rewrite - check against your mappings if this doesn't compile.
        context.getMatrices().push();
        context.getMatrices().translate(centerX - textRenderer.getWidth(time), y + 14, 0);
        context.getMatrices().scale(2f, 2f, 1f);
        context.drawText(textRenderer, time, 0, 0, 0xFFFFFFFF, true);
        context.getMatrices().pop();

        String playerName = client.getSession() != null ? client.getSession().getUsername() : "Player";
        String greeting = greetingForHour(now.getHour()) + ", " + playerName;
        context.drawCenteredTextWithShadow(textRenderer, greeting, centerX, y + 60, 0xFFC9C9D4);

        GlassRenderer.panel(context, centerX - totalPanelWidth() / 2 - 12, y - 10, totalPanelWidth() + 24, 100,
                0x20000000, 0x20FFFFFF);
    }

    private int totalPanelWidth() {
        return 220;
    }

    private String greetingForHour(int hour) {
        if (hour < 12) return "Good morning";
        if (hour < 18) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
