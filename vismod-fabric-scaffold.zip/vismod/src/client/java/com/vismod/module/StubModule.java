package com.vismod.module;

/**
 * Placeholder for a module that exists in the config UI (toggle persists,
 * shows up in search/categories/star list) but has no effect wired up yet.
 * Swap a StubModule registration for a real subclass in ModuleRegistry as
 * you implement each one - the id stays the same so nobody's saved config
 * breaks.
 */
public final class StubModule extends Module {
    public StubModule(String id, String displayName, ModuleCategory category, String description) {
        super(id, displayName, category, description, false);
    }
}
