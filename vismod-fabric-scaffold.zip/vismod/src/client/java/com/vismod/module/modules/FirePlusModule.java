package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.random.Random;

/** IMPLEMENTED - adds extra flame + smoke particles to any burning entity, including yourself. */
public class FirePlusModule extends Module {

    private final Random random = Random.create();

    public FirePlusModule() {
        super("fire_plus", "Fire+", ModuleCategory.ENTITIES,
                "Bigger, denser flame particles on any entity that's on fire.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;

        for (Entity entity : world.getEntities()) {
            if (!entity.isOnFire()) continue;

            for (int i = 0; i < 2; i++) {
                double x = entity.getX() + (random.nextDouble() - 0.5) * entity.getWidth() * 1.2;
                double y = entity.getY() + random.nextDouble() * entity.getHeight() * 1.2;
                double z = entity.getZ() + (random.nextDouble() - 0.5) * entity.getWidth() * 1.2;
                world.addParticle(ParticleTypes.FLAME, x, y, z, 0.0, 0.03, 0.0);
            }
            if (random.nextFloat() > 0.6f) {
                world.addParticle(ParticleTypes.LARGE_SMOKE,
                        entity.getX(), entity.getY() + entity.getHeight() * 0.6, entity.getZ(),
                        0.0, 0.02, 0.0);
            }
        }
    }
}
