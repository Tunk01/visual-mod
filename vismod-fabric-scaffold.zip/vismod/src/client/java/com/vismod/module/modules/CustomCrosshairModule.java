package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * IMPLEMENTED - pairs with CrosshairMixin, which cancels the vanilla
 * crosshair draw call whenever this module is enabled. This module then
 * draws its own in HudRenderCallback (which always runs after the vanilla
 * HUD pass), so you get a clean swap instead of double-drawing.
 *
 * Also demonstrates the "extra settings" pattern - hasExtraSettings()
 * returns true and openSettings() would push a small color-picker screen;
 * wire that to your own Screen subclass when you build it out.
 */
public class CustomCrosshairModule extends Module {

    private int color = 0xFFFFFFFF; // ARGB, editable from the settings sub-screen
    private int size = 8;

    public CustomCrosshairModule() {
        super("custom_crosshair", "Custom Crosshair", ModuleCategory.STYLE,
                "Replace the vanilla crosshair with a recolorable custom one.", false);
        HudRenderCallback.EVENT.register(this::onHudRender);
    }

    private void onHudRender(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!isEnabled()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;

        int cx = context.getScaledWindowWidth() / 2;
        int cy = context.getScaledWindowHeight() / 2;
        int half = size / 2;

        // simple plus-shaped crosshair; swap for a textured draw if you want an icon instead
        context.fill(cx - half, cy - 1, cx + half, cy + 1, color);
        context.fill(cx - 1, cy - half, cx + 1, cy + half, color);
    }

    @Override
    public boolean hasExtraSettings() {
        return true;
    }

    @Override
    public void openSettings(MinecraftClient client) {
        // TODO: push a small Screen here with a color wheel + size slider,
        // then call setColor()/setSize() on change. Left as an exercise -
        // see gui/VisualsConfigScreen for the widget style to match.
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
