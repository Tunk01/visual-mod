package com.vismod.module.modules;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CelestialMath;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * IMPLEMENTED - "Skyboxes" slot repurposed as a proper aurora effect.
 *
 * Draws 3 drifting ribbon bands high overhead, each a soft vertical-fade
 * triangle strip positioned on the sky dome (same trick vanilla uses for
 * stars - geometry is placed relative to the camera, not the world, so it
 * never gets closer/farther as you move). Colors cycle slowly between
 * aurora green, cyan and violet; the ribbons wave using layered sine
 * functions so they never repeat in an obviously loopy way.
 *
 * RENDERING API NOTE: this uses the "classic" Tessellator/BufferBuilder/
 * RenderSystem immediate-mode path that's been stable for years. Mojang
 * has been actively reworking the renderer in recent snapshots (new
 * RenderPipeline/GpuBuffer abstractions) - if this doesn't compile as-is
 * against your exact 1.21.11 mappings, the fix is almost always just
 * swapping these calls for whatever the new pipeline's equivalent is;
 * the animation/placement math below (toCartesian, the wave functions)
 * doesn't change at all.
 */
public class AuroraSkyModule extends Module {

    private static final int BANDS = 3;
    private static final int SEGMENTS = 48;
    private static final double DOME_RADIUS = 100.0;
    private static final double ARC_DEGREES = 160.0; // how much of the horizon each band sweeps
    private static final double RIBBON_HALF_WIDTH_DEG = 9.0;

    private static final int COLOR_GREEN = 0x39FF8C;
    private static final int COLOR_CYAN = 0x4FE0FF;
    private static final int COLOR_VIOLET = 0xA06BFF;

    public AuroraSkyModule() {
        super("skyboxes", "Skyboxes", ModuleCategory.WORLD,
                "Animated aurora curtains across the night sky.", true);
        WorldRenderEvents.SKY.register(this::onRenderSky);
    }

    private void onRenderSky(WorldRenderContext context) {
        if (!isEnabled()) return;

        ClientWorld world = MinecraftClient.getInstance().world;
        if (world == null || !world.getRegistryKey().equals(net.minecraft.world.World.OVERWORLD)) return;
        if (!isNightEnough(world)) return;

        float timeSeconds = (System.currentTimeMillis() % 1_000_000L) / 1000f;
        Matrix4f positionMatrix = new Matrix4f(context.matrixStack().peek().getPositionMatrix());

        beginAdditiveBlend();

        Tessellator tessellator = Tessellator.getInstance();
        for (int band = 0; band < BANDS; band++) {
            drawBand(tessellator, positionMatrix, band, timeSeconds);
        }

        endAdditiveBlend();
    }

    /** Fades in starting a bit before full dark, matches vanilla star visibility roughly. */
    private boolean isNightEnough(ClientWorld world) {
        // vanilla's own star-visibility fade - rises as the sky darkens toward night
        float brightness = world.getStarBrightness(1.0f);
        return brightness > 0.1f;
    }

    private void drawBand(Tessellator tessellator, Matrix4f matrix, int bandIndex, float time) {
        double baseYaw = -ARC_DEGREES / 2.0 + bandIndex * 35.0; // stagger each band's start
        double basePitch = 35.0 + bandIndex * 14.0;             // stack bands at different heights
        double phase = bandIndex * 2.1;

        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

        for (int i = 0; i <= SEGMENTS; i++) {
            double t = i / (double) SEGMENTS; // 0..1 along the ribbon
            double yaw = baseYaw + t * ARC_DEGREES;

            // layered waves so the ribbon undulates instead of forming a smooth static arc
            double wave = Math.sin(t * 6.0 + time * 0.35 + phase) * 6.0
                    + Math.sin(t * 2.3 - time * 0.2 + phase) * 4.0;
            double pitch = basePitch + wave;

            // fade the ribbon out at both ends so it doesn't have a hard cutoff on the horizon
            float edgeFade = (float) Math.sin(Math.PI * t);
            int color = CelestialMath.lerpRgb(COLOR_GREEN,
                    (bandIndex % 2 == 0) ? COLOR_CYAN : COLOR_VIOLET,
                    (float) ((Math.sin(t * 3.0 + time * 0.5 + phase) + 1.0) / 2.0));

            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            Vector3f top = CelestialMath.toCartesian(yaw, pitch + RIBBON_HALF_WIDTH_DEG, DOME_RADIUS);
            Vector3f bottom = CelestialMath.toCartesian(yaw, pitch - RIBBON_HALF_WIDTH_DEG, DOME_RADIUS);

            float topAlpha = 0f; // fully transparent at the top edge
            float bottomAlpha = 0.45f * edgeFade; // glows brightest in the middle of the ribbon

            buffer.vertex(matrix, top.x, top.y, top.z).color(r, g, b, topAlpha);
            buffer.vertex(matrix, bottom.x, bottom.y, bottom.z).color(r, g, b, bottomAlpha);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private void beginAdditiveBlend() {
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
    }

    private void endAdditiveBlend() {
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }
}
