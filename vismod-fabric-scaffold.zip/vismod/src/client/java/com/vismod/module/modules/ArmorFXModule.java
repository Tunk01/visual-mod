package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.random.Random;

/**
 * IMPLEMENTED EXAMPLE - "ambient particle emitter" pattern.
 * Any player wearing a full set of matching-tier armor gets a faint
 * particle aura. This is the template for Enchant Glint+, Fairy Rings,
 * Astral Dust, Rune Blooms, etc: all of them are "spawn particle(s)
 * around an entity when a condition is true", just with a different
 * condition and particle type.
 */
public class ArmorFXModule extends Module {

    private final Random random = Random.create();

    public ArmorFXModule() {
        super("armor_fx", "ArmorFX", ModuleCategory.ENTITIES,
                "Faint particle aura around players wearing a full matching armor set.", true);
    }

    @Override
    public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;

        for (PlayerEntity player : world.getPlayers()) {
            if (!hasFullArmor(player)) continue;
            if (random.nextFloat() > 0.3f) continue; // sparse, not a snowstorm

            double x = player.getX() + (random.nextDouble() - 0.5) * player.getWidth();
            double y = player.getY() + random.nextDouble() * player.getHeight();
            double z = player.getZ() + (random.nextDouble() - 0.5) * player.getWidth();

            world.addParticle(ParticleTypes.ENCHANT, x, y, z, 0.0, 0.01, 0.0);
        }
    }

    private boolean hasFullArmor(PlayerEntity player) {
        for (ItemStack stack : player.getArmorItems()) {
            if (stack.isEmpty()) return false;
        }
        return true;
    }
}
