package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.MusicTracker;
import net.minecraft.client.sound.SoundInstance;

/** IMPLEMENTED - small "Now Playing: <track>" pill, bottom-left, fades when no music is active. */
public class NowPlayingModule extends Module {

    public NowPlayingModule() {
        super("now_playing", "Now Playing", ModuleCategory.HUD,
                "Shows the current background music track name.", true);
        HudRenderCallback.EVENT.register(this::onHudRender);
    }

    private void onHudRender(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!isEnabled()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;

        MusicTracker.MusicInstance current = client.getMusicTracker().current();
        if (current == null) return;

        SoundInstance sound = current.sound();
        String trackId = sound.getId().getPath();
        // strip "music.something.actual_name" down to just the last segment for display
        String niceName = trackId.contains(".") ? trackId.substring(trackId.lastIndexOf('.') + 1) : trackId;
        niceName = niceName.replace('_', ' ');

        String label = "\u266A Now Playing: " + niceName;
        int screenHeight = context.getScaledWindowHeight();
        context.drawTextWithShadow(client.textRenderer, label, 6, screenHeight - 16, 0x90FFFFFF);
    }
}
