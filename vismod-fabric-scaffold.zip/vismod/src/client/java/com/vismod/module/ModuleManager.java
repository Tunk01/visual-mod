package com.vismod.module;

import com.vismod.config.ModuleConfig;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Single source of truth for every module. Registered once in
 * VisModClient#onInitializeClient, then driven by the client tick
 * event. The config screen reads straight from {@link #all()} and
 * calls {@link #setEnabled} / {@link #setStarred}, which immediately
 * persist to disk so a crash never loses a toggle.
 */
public final class ModuleManager {

    private static final Map<String, Module> MODULES = new LinkedHashMap<>();
    private static ModuleConfig config;

    private ModuleManager() {}

    public static void register(Module module) {
        if (MODULES.putIfAbsent(module.id(), module) != null) {
            throw new IllegalStateException("Duplicate module id: " + module.id());
        }
    }

    /** Call once, after every module has been registered. Applies saved on/off + starred state. */
    public static void loadAndApply() {
        config = ModuleConfig.load();
        for (Module module : MODULES.values()) {
            ModuleConfig.Entry entry = config.get(module.id());
            if (entry != null) {
                module.setEnabled(entry.enabled);
                module.setStarred(entry.starred);
            } else {
                // first launch: persist the coded default so modules.json is complete
                config.put(module.id(), module.isEnabled(), module.isStarred());
            }
        }
        config.save();
    }

    public static void setEnabled(Module module, boolean enabled) {
        module.setEnabled(enabled);
        persist(module);
    }

    public static void setStarred(Module module, boolean starred) {
        module.setStarred(starred);
        persist(module);
    }

    private static void persist(Module module) {
        config.put(module.id(), module.isEnabled(), module.isStarred());
        config.save();
    }

    public static Module get(String id) {
        return MODULES.get(id);
    }

    public static boolean isEnabled(String id) {
        Module m = MODULES.get(id);
        return m != null && m.isEnabled();
    }

    public static List<Module> all() {
        List<Module> list = new ArrayList<>(MODULES.values());
        list.sort(Comparator.comparing(Module::displayName));
        return list;
    }

    public static int enabledCount() {
        return (int) MODULES.values().stream().filter(Module::isEnabled).count();
    }

    public static int totalCount() {
        return MODULES.size();
    }

    public static void onClientTick(MinecraftClient client) {
        for (Module module : MODULES.values()) {
            if (module.isEnabled()) {
                module.onClientTick(client);
            }
        }
    }
}
