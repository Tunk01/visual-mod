package com.vismod.module;

import com.vismod.module.modules.*;

/**
 * Every module from the reference screenshots gets registered here so the
 * config screen's list/search/pagination matches exactly. A handful are
 * fully implemented (see module/modules/*.java for the patterns to copy);
 * the rest are StubModule/FlagModule placeholders - they toggle, persist,
 * and show up in the UI, but don't do anything yet.
 *
 * To implement one: write a Module subclass following the pattern of
 * ArmorFXModule (tick-based particles), PerformanceModule (HUD overlay),
 * or NametagMixin+FlagModule (mixin-driven), then swap its registration
 * line below. The id string must stay the same so existing players don't
 * lose their saved toggle state.
 */
public final class ModuleRegistry {

    private ModuleRegistry() {}

    public static void registerAll() {
        // ---- fully implemented ----
        ModuleManager.register(new ArmorFXModule());
        ModuleManager.register(new FirePlusModule());
        ModuleManager.register(new PlayerTrailsModule());
        ModuleManager.register(new JumpCirclesModule());
        ModuleManager.register(new HitEffectsModule());
        ModuleManager.register(new PerformanceModule());
        ModuleManager.register(new NowPlayingModule());
        ModuleManager.register(new CustomCrosshairModule());
        ModuleManager.register(new FlagModule("nametags", "Nametags", ModuleCategory.HUD,
                "Show/hide nametags above players and mobs.", true));
        ModuleManager.register(new FlagModule("weather", "Weather", ModuleCategory.WORLD,
                "Show/hide rain and snow rendering.", true));
        ModuleManager.register(new AuroraSkyModule());
        ModuleManager.register(new ShootingStarsModule());

        // ---- stubs: registered + visible in the UI, effect not wired up yet ----
        stub("menu_buttons", "Menu Buttons", ModuleCategory.STYLE, "Custom styling for in-game menu buttons.");
        stub("enchant_glint_plus", "Enchant Glint+", ModuleCategory.ENTITIES, "Enhanced enchantment glint shader.");
        stub("cherry_petals", "Cherry Petals", ModuleCategory.WORLD, "Ambient falling cherry petal particles.");
        stub("frost_flakes", "Frost Flakes", ModuleCategory.WORLD, "Ambient falling frost particles in cold biomes.");
        stub("prismatic_bubbles", "Prismatic Bubbles", ModuleCategory.WORLD, "Ambient rising rainbow bubble particles.");
        stub("prism_shards", "Prism Shards", ModuleCategory.WORLD, "Ambient glinting shard particles.");
        stub("wandering_souls", "Wandering Souls", ModuleCategory.ENTITIES, "Soul wisp particles drifting off mobs.");
        stub("fairy_rings", "Fairy Rings", ModuleCategory.WORLD, "Mushroom-ring particle circles in forests.");
        stub("attack_indicator", "Attack Indicator", ModuleCategory.HUD, "Custom attack cooldown indicator.");
        stub("larp", "Larp", ModuleCategory.MISC, "Roleplay flourishes.");
        stub("three_d_swords", "3D Swords", ModuleCategory.STYLE, "Renders held swords in full 3D instead of flat.");
        stub("autumn_leaves", "Autumn Leaves", ModuleCategory.WORLD, "Ambient falling leaf particles.");
        stub("ember_drift", "Ember Drift", ModuleCategory.WORLD, "Drifting ember particles near fire/lava.");
        stub("astral_dust", "Astral Dust", ModuleCategory.WORLD, "Ambient sparkling dust at night.");
        stub("lunar_moths", "Lunar Moths", ModuleCategory.WORLD, "Moth particles that gather near light at night.");
        stub("rune_blooms", "Rune Blooms", ModuleCategory.WORLD, "Glowing rune-shaped flower particles.");
        stub("crystal_gardens", "Crystal Gardens", ModuleCategory.WORLD, "Ambient crystal shard formations.");
        stub("ley_lines", "Ley Lines", ModuleCategory.WORLD, "Glowing energy line overlays across terrain.");
        stub("energy_vortices", "Energy Vortices", ModuleCategory.WORLD, "Swirling energy particle vortices.");
        stub("rift_sparks", "Rift Sparks", ModuleCategory.WORLD, "Spark particles near portals/rifts.");
        stub("anchor_fx", "Anchor FX", ModuleCategory.ENTITIES, "Particle effect on respawn anchor use.");
        stub("fireflies", "Fireflies", ModuleCategory.WORLD, "Ambient firefly particles at night.");
        stub("angel_wings", "Angel Wings", ModuleCategory.ENTITIES, "Cosmetic wing overlay on players.");
        stub("custom_sounds", "Custom Sounds", ModuleCategory.STYLE, "Swap in a custom sound pack.");
        stub("hostile_mobs", "Hostile mobs", ModuleCategory.ENTITIES, "Extra visual tells on hostile mobs.");
        stub("light_pillars", "Light Pillars", ModuleCategory.WORLD, "Vertical light beams on rare drops.");
        stub("orbiting_relics", "Orbiting Relics", ModuleCategory.ENTITIES, "Cosmetic items orbiting the player.");
        stub("player_animations", "Player Animations", ModuleCategory.MOTION, "Extra idle/walk animation flourishes.");
        stub("party", "Party", ModuleCategory.MISC, "Celebration particle bursts for special events.");
        stub("explosion_fx", "ExplosionFX", ModuleCategory.ENTITIES, "Enhanced explosion particles/shockwave.");
        stub("china_hat", "China Hat", ModuleCategory.ENTITIES, "Cosmetic hat overlay.");
        stub("capes_and_elytra", "Capes & Elytra", ModuleCategory.ENTITIES, "Custom cape and elytra textures/physics.");
        stub("fake_player", "Fake Player", ModuleCategory.MISC, "Spawns a cosmetic fake player for screenshots.");
        stub("damage_feedback", "Damage Feedback", ModuleCategory.HUD, "Screen-edge flash when you take damage.");
        stub("dropped_items", "Dropped items", ModuleCategory.WORLD, "Enhanced rendering for item entities on the ground.");
        stub("projectiles", "Projectiles", ModuleCategory.ENTITIES, "Enhanced arrow/trident/snowball trails.");
        stub("anchor_shader", "Anchor shader", ModuleCategory.STYLE, "Custom shader applied near respawn anchors.");
        stub("ambient_particles", "Ambient particles", ModuleCategory.WORLD, "General-purpose ambient particle layer.");
        stub("atmosphere", "Atmosphere", ModuleCategory.WORLD, "Fog/haze density and tint control.");
        stub("color_grading", "Color grading", ModuleCategory.STYLE, "Global post-processing color grade.");

        stub("end_crystals", "End crystals", ModuleCategory.ENTITIES, "Enhanced end crystal beam/particles.");
        stub("experience", "Experience", ModuleCategory.HUD, "Custom XP bar styling.");
        stub("block_highlights", "Block highlights", ModuleCategory.STYLE, "Custom block outline/highlight style.");
        stub("player_effects", "Player effects", ModuleCategory.ENTITIES, "Visual overlay for active status effects.");
        stub("celestial_effects", "Celestial effects", ModuleCategory.WORLD, "Custom sun/moon rendering.");
        stub("hud", "HUD", ModuleCategory.HUD, "Master HUD layout/style toggle.");
        stub("cinematic_menus", "Cinematic menus", ModuleCategory.STYLE, "Animated transitions between menu screens.");
        stub("discord_rich_presence", "Discord Rich Presence", ModuleCategory.MISC, "Shows your current activity in Discord.");

        stub("viewmodel", "Viewmodel", ModuleCategory.STYLE, "Held-item viewmodel position/scale/sway.");
        stub("swing_customizer", "Swing Customizer", ModuleCategory.MOTION, "Custom arm swing speed/arc.");
        stub("freelook", "Freelook", ModuleCategory.MOTION, "Decouple camera look from player body rotation.");
        stub("totem_particles", "Totem Particles", ModuleCategory.ENTITIES, "Custom totem-of-undying activation particles.");
        stub("totem_skins", "Totem Skins", ModuleCategory.STYLE, "Custom totem item texture packs.");
        stub("death_ghosts", "Death Ghosts", ModuleCategory.ENTITIES, "Ghost silhouette at your last death location.");
        stub("custom_fov", "Custom FOV", ModuleCategory.STYLE, "Fine-grained field-of-view control.");
        stub("player_afterimages", "Player Afterimages", ModuleCategory.MOTION, "Motion-blur style afterimages on fast movement.");
        stub("totem_size", "Totem Size", ModuleCategory.STYLE, "Scale of the totem-of-undying pop-up animation.");
        stub("totem_ghosts", "Totem Ghosts", ModuleCategory.ENTITIES, "Ghost trail during totem activation.");
        stub("camera", "Camera", ModuleCategory.MOTION, "Custom camera shake/smoothing settings.");
    }

    private static void stub(String id, String name, ModuleCategory category, String description) {
        ModuleManager.register(new StubModule(id, name, category, description));
    }
}
