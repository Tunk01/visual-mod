package com.vismod.module.modules;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CelestialMath;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.random.Random;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * IMPLEMENTED - pairs with AuroraSkyModule as the other "custom sky"
 * piece. Spawns an occasional streak that sweeps across the dome and
 * fades out, with a short tapering tail. Ticking (spawn logic) and
 * rendering (drawing) are deliberately split: ticks are cheap and run
 * once per game tick, rendering runs once per frame.
 */
public class ShootingStarsModule extends Module {

    private record Star(double startYaw, double startPitch, double endYaw, double endPitch, long startedAtMs, long lifetimeMs) {
        float progress(long now) {
            return Math.min(1f, (now - startedAtMs) / (float) lifetimeMs);
        }
    }

    private static final double DOME_RADIUS = 100.0;
    private static final int MAX_CONCURRENT = 2;
    private static final float SPAWN_CHANCE_PER_TICK = 1f / 300f; // roughly every ~15s when conditions allow
    private static final int TAIL_SAMPLES = 10;
    private static final int STAR_COLOR = 0xFFFFFF;

    private final List<Star> activeStars = new ArrayList<>();
    private final Random random = Random.create();

    public ShootingStarsModule() {
        super("shooting_stars", "Shooting Stars", ModuleCategory.WORLD,
                "Occasional shooting star streaks across the night sky.", true);
        ClientTickEvents.END_WORLD_TICK.register(this::onWorldTick);
        WorldRenderEvents.SKY.register(this::onRenderSky);
    }

    private void onWorldTick(ClientWorld world) {
        if (!isEnabled()) return;
        if (!world.getRegistryKey().equals(net.minecraft.world.World.OVERWORLD)) return;
        if (world.getStarBrightness(1.0f) < 0.4f) return; // only once it's properly dark
        if (activeStars.size() >= MAX_CONCURRENT) return;
        if (random.nextFloat() > SPAWN_CHANCE_PER_TICK) return;

        spawnStar();
    }

    private void spawnStar() {
        double startYaw = random.nextDouble() * 360.0;
        double startPitch = 40.0 + random.nextDouble() * 40.0; // upper half of the sky
        double sweepYaw = 25.0 + random.nextDouble() * 35.0;
        double sweepPitch = -(10.0 + random.nextDouble() * 20.0); // streaks arc downward

        activeStars.add(new Star(
                startYaw, startPitch,
                startYaw + sweepYaw, startPitch + sweepPitch,
                System.currentTimeMillis(),
                700 + random.nextInt(600)));
    }

    private void onRenderSky(WorldRenderContext context) {
        if (!isEnabled() || activeStars.isEmpty()) return;

        long now = System.currentTimeMillis();
        Matrix4f matrix = new Matrix4f(context.matrixStack().peek().getPositionMatrix());

        beginAdditiveBlend();
        Tessellator tessellator = Tessellator.getInstance();

        Iterator<Star> it = activeStars.iterator();
        while (it.hasNext()) {
            Star star = it.next();
            float progress = star.progress(now);
            if (progress >= 1f) {
                it.remove();
                continue;
            }
            drawStar(tessellator, matrix, star, progress);
        }

        endAdditiveBlend();
    }

    private void drawStar(Tessellator tessellator, Matrix4f matrix, Star star, float headProgress) {
        float r = ((STAR_COLOR >> 16) & 0xFF) / 255f;
        float g = ((STAR_COLOR >> 8) & 0xFF) / 255f;
        float b = (STAR_COLOR & 0xFF) / 255f;

        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

        // overall fade-in / fade-out envelope so it doesn't pop in/out abruptly
        float envelope = CelestialMath.smoothPulse(headProgress);

        for (int i = 0; i <= TAIL_SAMPLES; i++) {
            // walk backward from the head along the tail, each step a bit further behind and dimmer
            float sampleT = headProgress - (i / (float) TAIL_SAMPLES) * 0.12f;
            if (sampleT < 0f) sampleT = 0f;

            double yaw = lerp(star.startYaw(), star.endYaw(), sampleT);
            double pitch = lerp(star.startPitch(), star.endPitch(), sampleT);
            Vector3f center = CelestialMath.toCartesian(yaw, pitch, DOME_RADIUS);

            // thin perpendicular offset so the tail has visible width instead of being a zero-width line
            Vector3f dir = CelestialMath.toCartesian(star.endYaw(), star.endPitch(), 1)
                    .sub(CelestialMath.toCartesian(star.startYaw(), star.startPitch(), 1));
            Vector3f perp = new Vector3f(-dir.z, 0, dir.x);
            if (perp.lengthSquared() > 0.0001f) perp.normalize();
            float width = 0.35f * (1f - (i / (float) TAIL_SAMPLES)); // taper toward the tail end

            float alpha = envelope * (1f - (i / (float) TAIL_SAMPLES));

            Vector3f a = new Vector3f(center).add(new Vector3f(perp).mul(width));
            Vector3f c = new Vector3f(center).sub(new Vector3f(perp).mul(width));

            buffer.vertex(matrix, a.x, a.y, a.z).color(r, g, b, alpha);
            buffer.vertex(matrix, c.x, c.y, c.z).color(r, g, b, alpha);
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private void beginAdditiveBlend() {
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.lineWidth(2.0f);
    }

    private void endAdditiveBlend() {
        RenderSystem.lineWidth(1.0f);
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    @Override
    protected void onDisable(MinecraftClient client) {
        activeStars.clear();
    }
}
